-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 29, 2023 at 04:53 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `desis_test`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `insert` (IN `rut_ciudadano` VARCHAR(12) CHARSET utf8mb4, IN `nombres` VARCHAR(60) CHARSET utf8mb4, IN `_alias` VARCHAR(50) CHARSET utf8mb4, IN `_email` VARCHAR(50) CHARSET utf8mb4, IN `_medio` VARCHAR(30) CHARSET utf8mb4, IN `candidato` VARCHAR(12) CHARSET utf8mb4, IN `_cut` VARCHAR(5) CHARSET utf8mb4, OUT `message` VARCHAR(255) CHARSET utf8mb4)  DETERMINISTIC BEGIN
DECLARE es_candidato CHAR(12) DEFAULT "00.000.000-0";
DECLARE rut_votado CHAR(12) DEFAULT "00.000.000-0";
DECLARE message CHAR(255) DEFAULT 'Estimada(o), su voto no ha sido registrado.';

SELECT rut INTO es_candidato FROM candidatos WHERE rut = rut_ciudadano;
SELECT rut_candidato_votado INTO rut_votado FROM ciudadanos 
WHERE rut = rut_ciudadano AND rut_candidato_votado != '00.000.000-0';

IF rut_ciudadano = candidato THEN
    SIGNAL SQLSTATE '42000' 
    SET MESSAGE_TEXT = '-Estimada(o) candidata(o), no puede votar por usted misma(o).';
ELSEIF rut_votado != '00.000.000-0' THEN
    SIGNAL SQLSTATE '42000' 
    SET MESSAGE_TEXT = '-Estimada(o), ya ejerció su derecho a votar anteriormente.';
ELSEIF es_candidato = "00.000.000-0" AND rut_votado = '00.000.000-0' THEN
    BEGIN
    INSERT INTO `ciudadanos` 
    (rut, nombres_apellidos, alias, email, medio, rut_candidato_votado, cut) 
    VALUES (rut_ciudadano, nombres, _alias, _email, _medio, candidato, _cut); 
    SET @message = '-Estimada(o), su voto ha sido registrado con éxito.';
    END;
ELSEIF es_candidato != '00.000.000-0' AND rut_votado = '00.000.000-0' THEN
	BEGIN
    UPDATE `ciudadanos` SET medio = _medio, rut_candidato_votado = candidato 
    WHERE rut = rut_ciudadano;
    SET @message = '-Estimada(o) candidata(o), su voto ha sido registrado con éxito.';
    END;
END IF;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `candidatos`
--

CREATE TABLE `candidatos` (
  `rut` varchar(12) COLLATE utf8_spanish2_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Dumping data for table `candidatos`
--

INSERT INTO `candidatos` (`rut`) VALUES
('18.972.631-7'),
('9.068.826-k');

-- --------------------------------------------------------

--
-- Table structure for table `ciudadanos`
--

CREATE TABLE `ciudadanos` (
  `rut` varchar(12) COLLATE utf8_spanish2_ci NOT NULL,
  `nombres_apellidos` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `alias` varchar(30) COLLATE utf8_spanish2_ci NOT NULL,
  `email` varchar(50) COLLATE utf8_spanish2_ci NOT NULL DEFAULT '''usuario@dominio.com''',
  `medio` varchar(30) COLLATE utf8_spanish2_ci NOT NULL,
  `rut_candidato_votado` varchar(12) COLLATE utf8_spanish2_ci NOT NULL DEFAULT '00.000.000-0',
  `cut` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Dumping data for table `ciudadanos`
--

INSERT INTO `ciudadanos` (`rut`, `nombres_apellidos`, `alias`, `email`, `medio`, `rut_candidato_votado`, `cut`) VALUES
('12.345.678-5', 'Lorena Treto Márquez', 'Tatica', 'lorena@gmail.com', 'TV, Web, Redes sociales', '9.068.826-k', 1107),
('14.569.484-1', 'Jorge Alain Rodríguez Márquez', 'jorgito', 'jorgealain@gmail.com', 'Redes sociales, Amigo', '18.972.631-7', 1107),
('18.972.631-7', 'Beatriz Márquez Corredera', 'Betty', 'betty@gmail.com', 'TV, Redes sociales', '9.068.826-k', 15101),
('30.236.236-k', 'Alain Rey', 'lolo22', 'alainreym8@gmail.com', 'Web, Redes sociales', '18.972.631-7', 15101),
('30.686.957-4', 'Yalili Márquez Corredera', 'Lili', 'lili@gmail.com', 'TV, Amigo, Web', '18.972.631-7', 15202),
('30.686.957-6', 'fghgfhfg', 'fghgfhfg', 'gfhgfhf@dfgd.co', 'dffddfgdfs', '18.972.631-7', 15201),
('9.068.826-k', 'Daniel Treto Márquez', 'Danito', 'daniel@gmail.com', '', '00.000.000-0', 15202),
('90.068.826-1', 'David Treto Márquez', 'Davisito', 'david@gmail.com', 'TV, Web, Redes sociales, Amigo', '9.068.826-k', 15101);

-- --------------------------------------------------------

--
-- Table structure for table `comunas`
--

CREATE TABLE `comunas` (
  `cut` int(5) NOT NULL,
  `comuna` varchar(25) COLLATE utf8_spanish2_ci NOT NULL,
  `id_provincia` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Dumping data for table `comunas`
--

INSERT INTO `comunas` (`cut`, `comuna`, `id_provincia`) VALUES
(1101, 'Iquique', 3),
(1107, 'Alto Hospicio', 3),
(1401, 'Pozo Almonte', 4),
(1402, 'Camiña', 4),
(15101, 'Arica', 1),
(15102, 'Camarones', 1),
(15201, 'Putre', 2),
(15202, 'General Lagos', 2);

-- --------------------------------------------------------

--
-- Table structure for table `medios`
--

CREATE TABLE `medios` (
  `id` int(2) NOT NULL,
  `tipo` varchar(14) COLLATE utf8_spanish2_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Dumping data for table `medios`
--

INSERT INTO `medios` (`id`, `tipo`) VALUES
(1, 'TV'),
(2, 'Web'),
(3, 'Redes sociales'),
(4, 'Amigo');

-- --------------------------------------------------------

--
-- Table structure for table `provincias`
--

CREATE TABLE `provincias` (
  `id` int(2) NOT NULL,
  `provincia` varchar(30) COLLATE utf8_spanish2_ci NOT NULL,
  `id_region` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Dumping data for table `provincias`
--

INSERT INTO `provincias` (`id`, `provincia`, `id_region`) VALUES
(1, 'Arica', 15),
(2, 'Parinacota', 15),
(3, 'Iquique', 1),
(4, 'Tamarugal', 1);

-- --------------------------------------------------------

--
-- Table structure for table `regiones`
--

CREATE TABLE `regiones` (
  `id` int(2) NOT NULL,
  `region` varchar(30) COLLATE utf8_spanish2_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

--
-- Dumping data for table `regiones`
--

INSERT INTO `regiones` (`id`, `region`) VALUES
(1, 'Tarapacá'),
(15, 'Arica y Parinacota');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `candidatos`
--
ALTER TABLE `candidatos`
  ADD PRIMARY KEY (`rut`);

--
-- Indexes for table `ciudadanos`
--
ALTER TABLE `ciudadanos`
  ADD PRIMARY KEY (`rut`),
  ADD KEY `cut` (`cut`);

--
-- Indexes for table `comunas`
--
ALTER TABLE `comunas`
  ADD PRIMARY KEY (`cut`),
  ADD KEY `id_provincia` (`id_provincia`);

--
-- Indexes for table `medios`
--
ALTER TABLE `medios`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `provincias`
--
ALTER TABLE `provincias`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_region` (`id_region`);

--
-- Indexes for table `regiones`
--
ALTER TABLE `regiones`
  ADD PRIMARY KEY (`id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `candidatos`
--
ALTER TABLE `candidatos`
  ADD CONSTRAINT `candidatos_ibfk_1` FOREIGN KEY (`rut`) REFERENCES `ciudadanos` (`rut`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ciudadanos`
--
ALTER TABLE `ciudadanos`
  ADD CONSTRAINT `ciudadanos_ibfk_1` FOREIGN KEY (`cut`) REFERENCES `comunas` (`cut`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `comunas`
--
ALTER TABLE `comunas`
  ADD CONSTRAINT `comunas_ibfk_1` FOREIGN KEY (`id_provincia`) REFERENCES `provincias` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `provincias`
--
ALTER TABLE `provincias`
  ADD CONSTRAINT `provincias_ibfk_1` FOREIGN KEY (`id_region`) REFERENCES `regiones` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
