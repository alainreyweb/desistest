/**
 * Created by alainmc on 4/1/2018.
 **/

"use strict";

(function ($) {

    function clean(rut) {
        return typeof rut === 'string'
            ? rut.replace(/^0+|[^0-9kK]+/g, '').toUpperCase()
            : ''
    }

    function validate(rut) {
        if (typeof rut !== 'string') {
            return false
        }

        // if it starts with 0 we return false
        // so a rut like 00000000-0 will not pass
        if (/^0+/.test(rut)) {
            return false
        }

        if (!/^0*(\d{1,3}(\.?\d{3})*)-?([\dkK])$/.test(rut)) {
            return false
        }

        rut = clean(rut)

        let t = parseInt(rut.slice(0, -1), 10)
        let m = 0
        let s = 1

        while (t > 0) {
            s = (s + (t % 10) * (9 - (m++ % 6))) % 11
            t = Math.floor(t / 10)
        }

        const v = s > 0 ? '' + (s - 1) : 'K'
        return v === rut.slice(-1)
    }

    function format(rut, options = {
        dots: true
    }) {
        rut = clean(rut)

        let result
        if (options.dots) {
            result = rut.slice(-4, -1) + '-' + rut.substr(rut.length - 1)
            for (let i = 4; i < rut.length; i += 3) {
                result = rut.slice(-3 - i, -i) + '.' + result
            }
        } else {
            result = rut.slice(0, -1) + '-' + rut.substr(rut.length - 1)
        }

        return result
    }

    function getCheckDigit(input) {
        const rut = Array.from(clean(input), Number)

        if (rut.length === 0 || rut.includes(NaN)) {
            throw new Error(`"${input}" as RUT is invalid`)
        }

        const modulus = 11
        const initialValue = 0
        const sumResult = rut
            .reverse()
            .reduce(
                (accumulator, currentValue, index) =>
                    accumulator + currentValue * ((index % 6) + 2),
                initialValue
            )

        const checkDigit = modulus - (sumResult % modulus)

        if (checkDigit === 10) {
            return 'K'
        } else if (checkDigit === 11) {
            return '0'
        } else {
            return checkDigit.toString()
        }
    }

    const mostrar_modal = (title, text, type, insertado) => {
        //return Swal(title, text, type);
        let showcancelbutton = false, showconfirmbutton = true;
        if (insertado) {
            showcancelbutton = true;
            showconfirmbutton = false;
        }

        Swal.fire({
            title: title,
            html: text,
            type: type,
            showCancelButton: showcancelbutton,
            showConfirmButton: showconfirmbutton,
            confirmButtonColor: '#006dcc',
            cancelButtonColor: '#016928',
            focusCancel: true,
            confirmButtonText: 'Aceptar',
            cancelButtonText: 'Recargar',

        }).then((result) => {
            if (!result.value) {
                window.location.assign("http://desistest");
            }
        });

    }

    const actualizar_voto = (voto) => {
        $.ajax({
            url: 'http://desistest/script/script.php?method=update_vote',
            type: 'POST',
            dataType: 'text',
            timeout: 2000,
            async: false,
            data: voto,
            beforeSend: (info) => {
            },
            success: (response) => {
                let json_datos = JSON.parse(response);
                if (json_datos.data.insertado) {
                    mostrar_modal('Voto registrado.', json_datos.data.message, 'success');
                    //, '<a class="btn btn-default" type="button" href="http://desistest/">Recargar</a>'
                } else if (!json_datos.data.insertado) {
                    mostrar_modal('Error.', '<pre>' + json_datos.data.message + '</pre>', 'error');
                }
                window.location.assign("http://desistest");
            },
            complete: (response, textStatus) => {
                window.location.assign("http://dte.uclv.edu.cu");

            },
            error: (response) => {
                Swal('', 'Estimada(o), ha ocurrido un error al registrar su voto.', 'error');
            }
        });

    }

    const confirmar = () => {

        let cadena = "";
        for (let item of $("#medios")[0]) {
            if (item.selected) {
                cadena += item.text + ", ";
            }
        }

        let voto = {
            rut: $("#rut").val(),
            nombres_apellidos: $("#nombres_apellidos").val(),
            alias: $("#alias").val(),
            email: $("#email").val(),
            medios: cadena.substr(0, cadena.length - 2),
            candidato: $("#candidatos").val(),
            cut: $("#comunas").val(),
        };

        Swal.fire({
            title: 'Confirmar datos.',
            text: '¿Son correctos los datos que ha introducido?',
            type: 'question',
            showCancelButton: true,
            confirmButtonColor: '#2C812D',
            cancelButtonColor: '#770404',
            focusCancel: true,
            confirmButtonText: 'Sí',
            cancelButtonText: 'No',
        }).then((result) => {
            if (result.value) {
                $.ajax({
                    url: 'http://desistest/script/script.php?method=update_vote',
                    type: 'POST',
                    dataType: 'text',
                    timeout: 2000,
                    async: false,
                    data: voto,
                    beforeSend: (info) => {
                    },
                    success: (response) => {
                        let json_datos = JSON.parse(response);
                        if (json_datos.data.insertado) {
                            mostrar_modal('Voto registrado.', json_datos.data.message, 'success', json_datos.data.insertado);
                            //window.location.assign("http://desistest");
                        } else if (!json_datos.data.insertado) {
                            mostrar_modal('Error.', '<pre>' + json_datos.data.message + '</pre>', 'error', json_datos.data.insertado);
                        }
                    },
                    complete: (response, textStatus) => {
                    },
                    error: (response) => {
                        Swal('', 'Estimada(o), ha ocurrido un error al registrar su voto.', 'error');
                    }
                });

            }
        });
    }

    const select_regiones_candidatos = () => {
        $.ajax({
            url: 'http://desistest/script/script.php?method=select_regiones_candidatos_medios',
            type: 'GET',
            dataType: 'text',
            timeout: 2000,
            async: false,
            beforeSend: (info) => {
                //console.log('Before send: ', info);
            },
            success: (response) => {
                let json_datos = JSON.parse(response);
                let candidatos_children = [];
                json_datos.data.candidatos.forEach(
                    (value, index, array) => {
                        candidatos_children.push({
                            "id": json_datos.data.candidatos[index].rut,
                            "text": json_datos.data.candidatos[index].nombres_apellidos
                        });
                    });
                let candidatos_results = {"data": [{"text": "Candidatos: ", "children": candidatos_children}]};
                $('#candidatos').select2({
                    theme: "classic",
                    placeholder: 'Candidatos: ',
                    data: candidatos_results.data,
                    allowClear: true
                });

                let regiones_children = [];
                json_datos.data.regiones.forEach(
                    (value, index, array) => {
                        regiones_children.push({
                            "id": json_datos.data.regiones[index].id,
                            "text": json_datos.data.regiones[index].region
                        });
                    });
                let results = {"data": [{"text": "Regiones: ", "children": regiones_children}]};
                $('#regiones').select2({
                    theme: "classic",
                    placeholder: 'Regiones: ',
                    data: results.data,
                    allowClear: true
                });

                let medios_children = [];
                json_datos.data.medios.forEach(
                    (value, index, array) => {
                        medios_children.push({
                            "id": json_datos.data.medios[index].id,
                            "text": json_datos.data.medios[index].tipo
                        });
                    });
                let medios_results = {"data": [{"text": "Medios: ", "children": medios_children}]};
                $('#medios').select2({
                    //width: '50%',
                    theme: 'classic',
                    placeholder: 'Medios:',
                    data: medios_results.data,
                    allowClear: true,
                    multiple: true,
                });
            },
            complete: (response, textStatus) => {
            },
            error: () => {
                Swal('Error.', 'Estimada(o), ha ocurrido un error en la conexión con el servidor.', 'error');
            }
        });
    }

    const select2_triggers = () => {
        $('#candidatos').val('-1');
        $('#candidatos').trigger('change');
        $('#regiones').val('-1');
        $('#regiones').trigger('change');
        $('#comunas').val('-1');
        $('#comunas').trigger('change');
    }

    const validar_form = () => {

        if (!$("#nombres_apellidos").val()) {
            mostrar_modal('Aviso.', 'Estimada(o), el campo "Nombre y apellidos" no es válido.', 'warning', false);
            return false;
        } else if (!(/[a-zA-Z0-9]{5}$/i.test($("#alias").val()))) {
            mostrar_modal('Aviso.', 'Estimada(o), el campo "Alias" no es válido.', 'warning', false);
            return false;
        } else if (!validate($('#rut').val())) {
            mostrar_modal('Error.', 'Estimada(o), el campo "RUT" no es válido.', 'error', false);
            return false;

        } else if (!(/[a-zA-Z0-9]*@[a-zA-Z0-9]*\.[a-zA-Z]/).test($("#email").val())) {
            mostrar_modal('Aviso.', 'Estimada(o), el campo "Email" no es válido.', 'warning', false);
            return false;
        } else if (!$("#regiones").val()) {
            mostrar_modal('Aviso.', 'Estimada(o), el campo "Regiones" no es válido.', 'warning', false);
            return false;
        } else if (!$("#comunas").val()) {
            mostrar_modal('Aviso.', 'Estimada(o), el campo "Comunas" no es válido.', 'warning', false);
            return false;//COMPROBAR QUE SEAN 2 MEDIOS !$("#alias").val()
        } else if (!$("#candidatos").val()) {
            mostrar_modal('Aviso.', 'Estimada(o), el campo "Candidato" no es válido.', 'warning', false);
            return false;
        } else if ($("#medios").val() === null || $("#medios").val().length < 2) {
            mostrar_modal('Aviso.', 'Estimada(o), el campo "Medios" debe contener al menos 2.', 'warning', false);
            return false;
        } else {
            confirmar();
            return false;
        }
    }

    jQuery("document").ready(() => {
        select_regiones_candidatos();
        select2_triggers();

        $('#regiones').on('select2:select', (e) => {
            let data = e.params.data;
            $.ajax({
                url: 'http://desistest/script/script.php?method=select_comunas',
                type: 'GET',
                dataType: 'text',
                data: 'region_id=' + data.id,
                timeout: 3000,
                async: false,
                beforeSend: (info) => {
                },
                success: (response) => {
                    let json_datos = JSON.parse(response);
                    let provincias = JSON.parse(response);
                    //VACIAR EL SELECT ANTES DE LLENARLO
                    $("#comunas").children().detach();
                    let data_comunas = [{"text": "", "children": []}];
                    for (let i = 0; i < json_datos.data.provincias.length; i++) {
                        let comunas_children = [];
                        for (let j = 0; j < json_datos.data.provincias[i].comunas.length; j++) { //, provincias[i][j].comuna
                            //console.log("Provincia: ", provincias[i], "Comunas: ", provincias[i].comunas[j].comuna);
                            //$("#comunas").append("<option value='" + json_datos[i][j].cut + "'>" + json_datos[i][j].comuna + "</option>");
                            //$(".cl-comunas").append("<option value='" + json_datos[i][j].cut + "'>" + json_datos[i][j].comuna + "</option>");

                            comunas_children.push({
                                "id": json_datos.data.provincias[i].comunas[j].cut,
                                "text": json_datos.data.provincias[i].comunas[j].comuna
                            });

                        }
                        data_comunas.push({
                            "text": json_datos.data.provincias[i].provincia + ': ',
                            "children": comunas_children
                        });
                    }

                    /*for (comuna in comunas) {
                        $("#comunas").append("<option value='" + comunas['comuna'].cut + "'>" + comunas.comuna.comuna + "</option>");
                    }*/

                    $('#comunas').select2({
                        language: "es",
                        theme: "classic",
                        placeholder: {
                            id: '-1', // the value of the option
                            text: 'Listado de comunas.',
                        },
                        allowClear: true,
                        data: data_comunas,

                    });
                },
                complete: (response, textStatus) => {
                },
                error: () => {
                    Swal('Error.', 'Estimada(o), ha ocurrido un error en la conexión con el servidor.', 'error');
                }
            });

        });

        $('form#desis_form').on('submit', () => {

            return validar_form();

            /*if (!validate($('#rut').val())) {
                Swal('', 'El RUT que ha introducido no es válido.', 'error');
                //FOCALIZAR EL CAMPO RUT
                return false;
                //COMPROBAR QUE SEAN 2 MEDIOS
            } else {
                // LANZAR EL AJAX DE ACTUALIZACIÓN DE VOTO

                let voto = {nombres_apellidos:$("#nombres_apellidos").val(), alias:$("#alias").val(),
                    rut:$("#rut").val(), email:$("#email").val(), candidato:$("#candidatos").val(), cut:$("#comunas").val()};
                $.ajax({
                    url: 'http://desistest/script/script.php?method=update_vote',
                    type: 'POST',
                    dataType: 'text',
                    timeout: 2000,
                    async: false,
                    data: voto,
                    beforeSend: function (info) {
                        //console.log('Before send: ', info);
                        // PREGUNTAR SI LOS DATOS SON CORRECTOS
                        console.log(voto);
                    },
                    success: function (response) {
                        console.log('AJAX : ', response);
                        let json_datos = JSON.parse(response);
                        console.log(json_datos);


                        //console.log(validate('18.972.631-7'));
                        return;

                    },
                    complete: function (response, textStatus) {

                        //console.log('Complete: ', response);
                    },
                    error: function () {
                        Swal('', 'Ha ocurrido un error durante la selección de las regiones.', 'error');
                    }
                });

            }*/
        });
    });
})(jQuery);