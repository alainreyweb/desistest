import {  validate, clean, format, getCheckDigit } from 'rut.js/index.js';

let lo = validate('9068826');
console.log('¿Será?: ', lo);