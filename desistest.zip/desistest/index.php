<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Desis Programming Test</title>


    <link rel="stylesheet" type="text/css" href="assets/css/style.css">
    <link rel="stylesheet" type="text/css" href="lib/bootstrap/css/bootstrap.min.css"/>
    <link rel="stylesheet" type="text/css" href="lib/bootstrap/css/bootstrap.css"/>
    <!-- SELECT2-->
    <link rel='stylesheet' href='lib/select2/css/select2.min.css'/>
    <!--<link rel="stylesheet" type="text/css" href="lib/bootstrap/css/bootstrap-responsive.css">-->
    <link rel="stylesheet" href="lib/sweetalert/sweetalert2.min.css"/>

</head>
<body>
<div id="page" style="">

    <header style='text-align: right'>
        <div><img src='assets/img/desis.jpg' height="32" width="186"/>
        </div>
    </header>

    <section id="de_form">
        <article>
            <form id="desis_form" name="desis_form" action="">
                <fieldset>
                    <h4 class="form-title">FORMULARIO DE VOTACIÓN</h4>
                    <div>
                        <label for='nombres_apellidos'>Nombre y apellidos:
                            <input class="inputstyle" type='text' name='nombres_apellidos' id="nombres_apellidos"
                                   placeholder='Nombre y los apellidos'></label>
                    </div>
                    <div>
                        <label for='alias'>Alias:
                            <input class='inputstyle' type='text' name='alias' placeholder='Alias' id="alias"
                            ></label><!-- pattern='[0-9A-Za-z]{6}' -->
                    </div>
                    <div>
                        <label for='rut'>Rut:
                            <input class='inputstyle' type='text' name='rut' placeholder='RUT: "XX.XXX.XXX-X'
                                   pattern='[1-9,0-9]{1,2}.[0-9]{3}.[0-9]{3}-[1-9,K,k]{1}' id="rut">
                        </label></div>
                    <div>
                        <label for='email'>Email:
                            <input class='inputstyle' type='email' name='email' placeholder='Email' id="email">
                        </label>
                    </div>
                    <!--pattern='[a-zA-Z0-9]*@[a-zA-Z0-9]*\.[a-zA-Z]'-->
                    <div>
                        <label for='regiones'>Regiones:
                            <select id='regiones' name='regiones' pattern='[a-zA-Z]'>
                            </select>
                        </label>
                    </div>
                    <div>
                        <label for='comunas'>Comunas:
                            <select id='comunas' name='comunas' pattern='[a-zA-Z]'>
                            </select></label>
                    </div>
                    <div>
                        <label for='candidatos'>Candidato:
                            <select id='candidatos' name='candidatos' pattern='[a-zA-Z]'>
                            </select></label>
                    </div>
                    <div class="">
                        <label for='medios'>¿Cómo se enteró de nosotros?
                            <select id='medios' name='medios' class='inputstyle'>
                            </select></label>
                    </div>
                    <div>
                        <button id="btn-votar" type='submit' class='btn btn-primary'>Votar</button>
                    </div>
                </fieldset>
            </form>
        </article>
    </section>

</div>
<footer>
    <div class='row ' style='padding: 25px 15px 15px 15px'>
        <div class='row col-md-4'>
            <p>FOOTER ONE</p>
        </div>
        <div class='row col-md-4'>
            <p>FOOTER TWO</p>
        </div>
        <div class='row col-md-4'>
            <p>FOOTER THREE</p>
        </div>
    </div>
</footer>
<script src='lib/jQuery3.7.1/jquery-3.7.1.min.js '></script>
<script src='lib/jQuery3.7.1/jquery-migrate-3.4.0.min.js '></script>
<script src="lib/bootstrap/js/bootstrap.min.js"></script>
<!-- SELECT2 -->
<script src='lib/select2/js/select2.js'></script>
<!-- SWEETALERT -->
<script src='lib/sweetalert/sweetalert2.min.js'></script>
<script type="module" src="assets/js/custom.js"></script>
</body>
</html>