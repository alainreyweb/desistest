const path = require('path');

module.exports = {
    entry: 'F:\\web\\htdocs\\desistest\\node-modules\\rut.js\\index.js',
    output: {
        path: path.resolve(__dirname, 'dist'),
        filename: 'build.js',
    },
};