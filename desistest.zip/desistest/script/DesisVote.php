<?php

/**
 * Created by PhpStorm.
 * User: alainmc
 * Date: 10/10/2023
 * Time: 2:18 PM
 */
class DesisVote
{
	private array $Request;

	function __construct(array $request)
	{

		$this->Request = $request;
	}

	public function desis_connect()
	{
		if ($this->Request['method'] == 'select_regiones_candidatos_medios') {
			$this->select_regiones_candidatos_medios($con = mysqli_connect('localhost:3306', 'root', '', 'desis_test'));
		} elseif ($this->Request['method'] == 'select_comunas') {
			$this->select_comunas($con = mysqli_connect('localhost:3306', 'root', '', 'desis_test'));
		} elseif ($this->Request['method'] == 'update_vote') {
			$this->update_vote($con = mysqli_connect('localhost:3306', 'root', '', 'desis_test'));
		} elseif ($this->Request['method'] == 'select_medios') {
			$this->select_medios($con = mysqli_connect('localhost:3306', 'root', '', 'desis_test'));
		}
	}


	private function select_regiones_candidatos_medios($con)
	{
		$sql_candidatos = 'SELECT ciudadanos.rut, ciudadanos.nombres_apellidos  FROM ciudadanos, candidatos WHERE candidatos.rut = ciudadanos.rut ORDER BY nombres_apellidos';
		$result_candidatos = mysqli_query($con, $sql_candidatos);
		$data_ciudadanos = mysqli_fetch_all($result_candidatos, MYSQLI_ASSOC);

		$sql_regiones = 'SELECT * FROM regiones ORDER BY region';
		$result_regiones = mysqli_query($con, $sql_regiones);
		$data_regiones = mysqli_fetch_all($result_regiones, MYSQLI_ASSOC);

		$sql_medios = 'SELECT *  FROM medios';
		$result_medios = mysqli_query($con, $sql_medios);
		$data_medios = mysqli_fetch_all($result_medios, MYSQLI_ASSOC);

		echo json_encode(['data' => ['candidatos' => $data_ciudadanos, 'regiones' => $data_regiones, 'medios' => $data_medios]]);

		mysqli_free_result($result_candidatos);
		mysqli_free_result($result_regiones);
		mysqli_free_result($result_medios);

		mysqli_close($con);
	}

	private function select_comunas($con)
	{
		$region_id = $this->Request['region_id'];
		$sql_provincias = 'SELECT id, provincia FROM provincias WHERE id_region = ' . $region_id . ' ORDER BY provincia';
		$result_provincias = mysqli_query($con, $sql_provincias);
		$data_provincias = mysqli_fetch_all($result_provincias, MYSQLI_ASSOC);
		$data_comunas = array();

		foreach ($data_provincias as $value) {
			$sql_comunas = 'SELECT cut, comuna FROM comunas WHERE id_provincia = ' . $value['id'] . ' ORDER BY comuna';
			$result_comunas = mysqli_query($con, $sql_comunas);
			$data_comunas_provincias = array('provincia' => $value['provincia'], 'comunas' => mysqli_fetch_all($result_comunas, MYSQLI_ASSOC));
			array_push($data_comunas, $data_comunas_provincias);//mysqli_fetch_all($result_comunas, MYSQLI_ASSOC)
			mysqli_free_result($result_comunas);
		}

		echo json_encode(['data' => ['provincias' => $data_comunas]]);

		mysqli_free_result($result_provincias);
		mysqli_close($con);
	}

	private function update_vote($con)
	{

		if ($_SERVER['REQUEST_METHOD'] == 'POST') {
			$rut = $_POST['rut'];
			$nombres_apellidos = $_POST['nombres_apellidos'];
			$alias = $_POST['alias'];
			$email = $_POST['email'];
			$candidato = $_POST['candidato'];
			$cut = $_POST['cut'];
			$medio = $_POST['medios'];
			$p7 = '';

			if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

				$message = json_encode(['data' => ['insertado' => false, 'message' => 'La dirección de correo no es válida.']]);
				exit($message);
			}

			try {

				mysqli_query($con, 'CALL `insert`(' . "'$rut'," . "'$nombres_apellidos'," . "'$alias'," . "'$email'," . "'$medio'," . "'$candidato'," . "'$cut'," . '@p7' . ');');
				$select = mysqli_query($con, 'SELECT @message;');
				//$message = mysqli_fetch_all($select, MYSQLI_ASSOC);
				$message_row = mysqli_fetch_row($select);
				$message = json_encode(['data' => ['insertado' => true, 'message' => $message_row[0]]]);

				mysqli_close($con);
				exit($message);
			} catch (Exception $exception) {

				$message = $exception->getMessage();
				$message = json_encode(['data' => ['insertado' => false, 'message' => $message, 'error' => $exception->getCode()]]);

				mysqli_close($con);
				exit($message);
			}

		}
	}

}