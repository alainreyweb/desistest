<?php
/**
 * Created by PhpStorm.
 * User: alainmc
 * Date: 10/10/2023
 * Time: 2:18 PM
 */

include 'DesisVote.php';

$desis_vote = new DesisVote($_REQUEST);

$desis_vote->desis_connect();